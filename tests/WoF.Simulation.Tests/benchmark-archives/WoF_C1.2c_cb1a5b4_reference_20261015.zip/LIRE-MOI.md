# Archive de référence WoF — C1.2c

Archive constituée le 15 octobre 2026, après le commit C1.2c.

## Contenu

- `C1.2c/` : huit exécutions du benchmark, soit huit CSV et huit JSON, réalisées vers 21:08 UTC le 15 octobre 2026. Quatre exécutions de 250 duels, quatre d'une bataille de 500 divisions, en alternance.
- `C1.2b-reference/` : les huit exécutions précédentes servant à la comparaison, soit huit CSV et huit JSON, réalisées vers 20:07 UTC le même jour. Elles ne doivent pas être mélangées aux nouvelles mesures.
- `rapport_C1_2c_20261015_2108.md` : analyse détaillée, mesures individuelles, comparaison, anomalies temporelles et limites.
- `sources/C1.2c_cb1a5b4.zip` : code du moteur, du benchmark et de ses tests, README et .gitignore extraits du commit `cb1a5b4e147f38a3323f929cdf8890bd2da43427`.
- `sources/C1.2b_8ff92c9.zip` : mêmes répertoires extraits du commit `8ff92c9ba83eb5165bf40af0e0ff6e60329a690a`.
- `MANIFEST_SHA256.json` : taille et empreinte SHA-256 de chacun des autres fichiers de l'archive. Le manifeste ne contient pas sa propre empreinte.

Les archives de sources ne contiennent ni l'historique Git, ni les binaires compilés, ni les dépendances téléchargées, ni le client graphique. Elles permettent de reconstruire les projets de simulation, de benchmark et de tests avec le SDK et les dépendances appropriés. La restauration initiale des dépendances peut nécessiter Internet.

## Provenance : distinction essentielle

Les JSON ont été conservés à l'identique. Ils portent toujours le label du programme de mesure `C1.2a`, indépendamment de la version optimisée du moteur.

Les mesures C1.2c enregistrent `GitRevision = 8ff92c9ba83eb5165bf40af0e0ff6e60329a690a` et `WorkingTreeDirty = true` : les modifications C1.2c étaient alors locales. Elles ont été committées ensuite sous `cb1a5b4e147f38a3323f929cdf8890bd2da43427` sur la branche `feature/c1-2c-loss-allocations`. Ce commit modifie les mêmes fichiers d'optimisation et de tests observés lors des mesures, ainsi que le README. Aucune empreinte complète des sources ou binaires n'avait été enregistrée au moment des mesures : l'identité binaire exacte avec une reconstruction ultérieure n'est donc pas certifiée.

De même, la référence C1.2b enregistre `GitRevision = 10ad5f5523f3a648cd88d41845abb89598c719bc` et `WorkingTreeDirty = true` ; le commit ultérieur d'agrégation par pays est `8ff92c9ba83eb5165bf40af0e0ff6e60329a690a`. L'archive des sources est une référence committée correspondante, sans réécriture des métadonnées de mesure.

Le rapport décrit l'état du dépôt au moment des benchmarks, avant le commit C1.2c. Son indication de modifications non committées reste donc historiquement correcte.

## Protocole

Compilation Release du projet de benchmark avant les huit nouvelles commandes, sans erreur ni avertissement. Exécution sous Debian 13 / WSL, .NET 10.0.12, X64, Server GC désactivé.

```bash
dotnet build src/WoF.Benchmarks/WoF.Benchmarks.csproj -c Release
dotnet run --project src/WoF.Benchmarks/WoF.Benchmarks.csproj -c Release --no-build -- combat 500 72 2 24
dotnet run --project src/WoF.Benchmarks/WoF.Benchmarks.csproj -c Release --no-build -- combat 500 72 500 24
```

Les deux dernières commandes ont été répétées en alternance quatre fois chacune : 500 divisions, 24 heures d'échauffement puis 72 ticks mesurés. Les CSV fournissent les mesures par tick ; les JSON fournissent l'environnement, les résumés, les validations et les états militaires aux bornes. Les sorties console n'ont pas été enregistrées dans un journal distinct ; les valeurs de construction et d'agrégation capturées dans la conversation sont consignées dans le rapport.

Les baisses d'allocations sont nettes, mais les durées présentent des plateaux et changements de régime : consulter les réserves du rapport avant toute extrapolation.

## Périmètre et conservation

Les anciens benchmarks C1.1, les mesures antérieures à C1.2b et les traces de profilage C1.2a sont exclus volontairement : ils ne proviennent pas de cette campagne de comparaison. Ils restent dans le dossier d'origine et n'ont pas été supprimés.

Les originaux de tous les fichiers archivés sont conservés. Aucun fichier source n'a été modifié et aucun commit n'a été créé pour l'archivage.

Le dossier `benchmark-results/`, où se trouve cette archive, est ignoré par Git. Un push de la branche ne sauvegarde pas l'archive : conserver aussi une copie dans un emplacement de sauvegarde indépendant.
