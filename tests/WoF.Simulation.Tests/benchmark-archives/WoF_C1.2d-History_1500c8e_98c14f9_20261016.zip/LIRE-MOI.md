# WoF — Archive comparative C1.2d-History

Archive préparée le 16 octobre 2026 à partir de la campagne comparative du même jour. Les originaux n'ont été ni déplacés, ni modifiés, ni supprimés.

## Versions exactes

| Sous-dossier | Moteur | Commit mesuré |
|---|---|---|
| `C1_2c_sans_index/` | C1.2c, sans indexation des engagements | `1500c8ed787515340cf3ba952b8cd1785d5a6693` |
| `C1_2d_avec_index/` | C1.2d, avec indexation | `98c14f9247f6d596d18e3f3104d39ef78a99c6da` |

Les 24 JSON enregistrent `WorkingTreeDirty = false`. Le benchmark a été ajouté à la version sans index par cherry-pick. `HistoryBenchmark.cs` est identique entre les deux versions : empreinte Git `3842698abb3dde0c824868240fe1d4df6ec588cc`. Dans les répertoires du moteur et du benchmark, seule la version d'`EngagementSystem.cs` diffère entre les deux commits.

## Contenu

- 12 couples CSV/JSON par version, soit 24 exécutions et 48 fichiers de résultats.
- Quatre niveaux d'historique : 0, 1 000, 5 000 et 10 000 batailles archivées, trois répétitions chacun.
- `RAPPORT.md` : compte rendu de l'analyse en lecture seule, tableaux, résultats individuels et limites.
- `sources/C1_2c_sans_index.zip` et `sources/C1_2d_avec_index.zip` : snapshots Git du moteur, du benchmark, des fichiers C# et projets de tests, du README et du .gitignore. Les anciennes archives de benchmark ne sont pas réembarquées dans ces snapshots.
- `MANIFEST_SHA256.json` : inventaire des fichiers avec leur taille et leur empreinte SHA-256. Il ne contient pas sa propre empreinte.

Les sources ne comprennent ni historique Git, ni binaires compilés, ni SDK .NET, ni packages téléchargés, ni client graphique. Leur inclusion préserve le code de référence mais ne certifie pas l'identité des binaires exécutés : aucune empreinte de ces binaires n'avait été enregistrée pendant les mesures.

Les deux essais préliminaires indexés, PID 9593 et 9630, sont exclus volontairement : ils enregistrent le commit antérieur `def525e90f5a38034c71b3e87f3706358ea95ea2` et des modifications non committées. Ils restent dans le dossier d'origine.

## Protocole

Toujours 500 divisions, 50 batailles actives de 10 divisions, 24 ticks d'échauffement puis 72 ticks mesurés par processus.

```bash
dotnet build src/WoF.Benchmarks/WoF.Benchmarks.csproj -c Release
dotnet run --project src/WoF.Benchmarks/WoF.Benchmarks.csproj -c Release --no-build -- history 0 72 24
dotnet run --project src/WoF.Benchmarks/WoF.Benchmarks.csproj -c Release --no-build -- history 1000 72 24
dotnet run --project src/WoF.Benchmarks/WoF.Benchmarks.csproj -c Release --no-build -- history 5000 72 24
dotnet run --project src/WoF.Benchmarks/WoF.Benchmarks.csproj -c Release --no-build -- history 10000 72 24
```

Chaque scénario a été répété trois fois par version. L'ordre sans/avec index est alterné entre répétitions. La préparation de l'historique est exclue du chronométrage. Chaque observation de recherche est la moyenne de cinq appels supplémentaires à `DetectProvinceEngagements()`, effectués juste avant le tick complet chronométré séparément.

Dates : les noms de fichiers sont en UTC, entre 00:32 et 00:33 le 16 octobre 2026, soit environ 02:32–02:33 à Paris.

Environnement enregistré : .NET 10.0.12, Debian 13 sous WSL, X64, 12 processeurs logiques, Server GC désactivé, `TieredPGOOverride = null`. Le champ de configuration Release est un libellé fixe du programme, pas une détection automatique de la configuration exécutée.

## Lecture des résultats

Le gain de recherche à 10 000 archives est d'environ x12,27 en moyenne. Aucun changement militaire agrégé n'a été détecté. En revanche, cette campagne ne démontre pas d'accélération globale du tick : les plateaux initiaux et changements de régime doivent être pris en compte. Consulter le rapport avant toute utilisation architecturale de ces chiffres.

La présente opération n'a relancé aucun test ni benchmark et n'a créé aucun commit. Les sorties console de cette campagne History n'ont pas été retrouvées sous forme de journal distinct et ne sont pas inventées dans cette archive.

## Conservation

Ce ZIP est placé dans le dossier déjà utilisé par le dépôt : `tests/WoF.Simulation.Tests/benchmark-archives/`. Il est destiné à pouvoir être ajouté explicitement à Git. Sa création n'effectue ni ajout à l'index Git, ni commit, ni push. Une copie sur un support indépendant reste utile.
