# WoF — Analyse C1.2d-History

## Conclusion

L'indexation apporte un bénéfice clairement mesurable à la détection provinciale lorsque l'historique augmente : à 10 000 archives, le temps moyen par passe est divisé par 12,27. La charge militaire et les états agrégés sont conservés.

Cette campagne ne démontre toutefois pas une accélération du tick complet. Celui-ci est plus lent en moyenne dans plusieurs configurations indexées, avec des plateaux initiaux très importants suivis d'accélérations. Il faut conserver ces résultats défavorables et ne pas les attribuer sans preuve à une régression intrinsèque de l'indexation.

Analyse initialement réalisée en lecture seule le 16 octobre 2026. Aucune mesure n'a été relancée pour cette analyse ou pour l'archivage. Le guide Spreadsheets a servi au recalcul et au contrôle des résultats CSV, rapprochés des JSON.

## 1. Population et provenance

24 couples CSV/JSON : deux versions, quatre niveaux d'historique, trois processus indépendants par configuration. Chaque processus fournit 72 observations, soit 1 728 lignes de mesures. Les deux essais préliminaires non committés sont exclus.

Sans index : `1500c8ed787515340cf3ba952b8cd1785d5a6693`. Avec index : `98c14f9247f6d596d18e3f3104d39ef78a99c6da`. Tous les JSON retenus indiquent un arbre de travail propre. Le code du benchmark est identique entre versions ; dans les répertoires du moteur et du benchmark, seul `EngagementSystem.cs` diffère.

Environnement commun : .NET 10.0.12, Debian 13 / WSL, X64, 12 processeurs logiques, Server GC désactivé, `TieredPGOOverride = null`. Le nombre de processeurs n'indique pas un traitement parallèle. Le champ `BuildConfiguration` est une chaîne fixe « Release (expected; use -c Release) » et ne certifie pas à lui seul la configuration réelle des binaires.

Les chemins des résultats sont préservés sous deux sous-dossiers distincts de l'archive. Le manifeste fournit les noms exacts et empreintes. Les PID de la section 8 relient chaque statistique individuelle à son couple de fichiers.

## 2. Validité militaire

Chaque CSV comporte exactement 72 ticks consécutifs. A chaque tick : 50 batailles actives, nombre d'archives demandé inchangé, 500 divisions capables de combattre et zéro division rompue.

Le code vérifie dix participants par bataille avant et après échauffement, mais ne réexporte pas la composition individuelle de chaque engagement à chaque tick. Les trois états militaires agrégés (avant échauffement, après échauffement, après mesure) sont strictement identiques entre toutes les versions, configurations et répétitions, à l'exception attendue du nombre de batailles archivées.

Etat final commun à l'heure simulée 97 : 4 808 000 personnels disponibles, 48 000 KIA cumulés, 144 000 WIA indisponibles/cumulés, zéro disparu ou capturé, organisation totale 4 716 185,000000043 et carburant total 10 444,999999999993. Aucun char opérationnel, endommagé ou détruit.

Les pertes cumulées incluent l'échauffement. Cette concordance ne constitue pas une preuve exhaustive d'équivalence par compagnie, par tick, ou sur des scénarios blindés.

## 3. Recherche provinciale

Temps en millisecondes par passe. Chaque observation est déjà une moyenne de cinq appels ; son p95 n'est pas celui des appels individuels. Les médianes et p95 ci-dessous sont recalculés sur les 216 observations regroupées de chaque version/scénario, sans moyenner des percentiles.

| Archives | C1.2c moyenne | Médiane | p95 | C1.2d moyenne | Médiane | p95 | Accélération moyenne |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 0,1362 | 0,1381 | 0,2152 | 0,1170 | 0,1120 | 0,1612 | x1,16 |
| 1 000 | 0,4091 | 0,2888 | 1,5400 | 0,1025 | 0,1007 | 0,1617 | x3,99 |
| 5 000 | 0,9584 | 0,3501 | 7,0209 | 0,1313 | 0,1115 | 0,1630 | x7,30 |
| 10 000 | 0,8797 | 0,8699 | 0,9753 | 0,0717 | 0,0649 | 0,1286 | x12,27 |

Réduction des moyennes : 14,1 %, 74,9 %, 86,3 % et 91,9 % respectivement.

A H10000, les moyennes individuelles sont de 0,862 à 0,908 ms sans index contre 0,068 à 0,078 ms avec index. Les plages sont largement séparées. Le bénéfice ne repose pas sur un seul processus favorable.

La moyenne H5000 sans index est supérieure à H10000 en raison de périodes lentes : on ne peut pas ajuster une loi temporelle précise sur ces seules moyennes. L'accélération apparente de l'index entre H0 et H10000 ne prouve pas non plus que l'ajout d'archives accélère intrinsèquement les dictionnaires.

Sensibilité après retrait des trois plus grandes observations de chaque processus, sans remplacer les résultats principaux : H1000 = 0,3581 contre 0,0984 ms ; H5000 = 0,7256 contre 0,1150 ms ; H10000 = 0,8709 contre 0,0667 ms. Le bénéfice ne disparaît pas après retrait de quelques extrêmes.

## 4. Tick complet

Temps en millisecondes par tick, médianes et p95 regroupés sur 216 observations.

| Archives | C1.2c moyenne | Médiane | p95 | C1.2d moyenne | Médiane | p95 | Variation de moyenne |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 6,857 | 6,523 | 12,407 | 6,186 | 5,476 | 14,938 | -9,8 % |
| 1 000 | 6,839 | 5,551 | 16,837 | 7,426 | 3,897 | 18,808 | +8,6 % |
| 5 000 | 4,857 | 3,212 | 15,076 | 6,788 | 5,457 | 15,595 | +39,8 % |
| 10 000 | 3,791 | 3,714 | 4,325 | 6,670 | 2,866 | 17,705 | +75,9 % |

Il serait incorrect d'annoncer un gain global à partir de cette campagne. Il serait également prématuré de transformer ces différences de moyennes en régression intrinsèque établie du moteur : les distributions ne sont pas stationnaires.

Les cinq recherches supplémentaires sont exclues du chronométrage du tick mais précèdent immédiatement celui-ci dans le même processus. Les durées sont séparées, pas les conditions d'exécution ni les effets éventuels sur les caches, le GC ou le calendrier du runtime.

## 5. Plateaux et stabilité temporelle

Exemple H10000, première répétition, moyenne des ticks par blocs de douze :

| Ticks | Sans index PID 10160 | Avec index PID 10198 |
|---|---:|---:|
| 1–12 | 3,797 | 17,628 |
| 13–24 | 3,674 | 13,112 |
| 25–36 | 3,850 | 3,134 |
| 37–48 | 3,770 | 2,668 |
| 49–60 | 3,867 | 2,600 |
| 61–72 | 3,538 | 2,334 |

Le phénomène apparaît dans les trois processus indexés H10000 : 63 ticks dépassent 10 ms sur 216, dont 62 dans les 24 premiers ticks de leur processus. Aucun tick H10000 sans index ne dépasse 10 ms.

Les 24 derniers ticks donnent 3,931 ms sans index contre 2,491 ms avec index. Ce sous-ensemble tardif n'est pas une nouvelle référence stabilisée certifiée : il montre que la conclusion change avec la portion d'exécution retenue.

A H5000, le processus sans index PID 10424 a une recherche moyenne de 1,341 ms et une médiane de 0,350 ms. Ses douze premières observations coûtent en moyenne 6,319 ms, les blocs suivants environ 0,32 à 0,38 ms. Le p95 élevé n'est donc pas uniquement une pause isolée.

Causes non déterminées : compilation tierée/PGO, effets de la préparation et des diagnostics supplémentaires, charge/fréquence/ordonnancement WSL, autres différences de régime. Aucune trace complémentaire CPU/JIT/GC n'a été enregistrée pour attribuer causalement ces plateaux.

## 6. Allocations et GC

Allocations moyennes en KiB (1 KiB = 1 024 octets).

| Archives | Recherche C1.2c / passe | Recherche C1.2d / passe | Tick C1.2c | Tick C1.2d |
|---:|---:|---:|---:|---:|
| 0 | 54,93 | 51,59 | 792,25 | 786,39 |
| 1 000 | 55,04 | 51,24 | 795,15 | 789,13 |
| 5 000 | 54,58 | 51,73 | 792,90 | 787,25 |
| 10 000 | 53,71 | 51,18 | 797,42 | 786,88 |

Réduction : environ 4,7 à 6,9 % pour la recherche et 0,7 à 1,3 % pour le tick. Les allocations restent approximativement indépendantes du volume d'historique : parcourir plus d'engagements ne nécessite pas forcément de créer davantage d'objets.

| Archives | GC C1.2c Gen0/1/2 | GC C1.2d Gen0/1/2 |
|---:|---|---|
| 0 | 9/0/0 sur les trois passages | 9/0/0 sur les trois passages |
| 1 000 | 9/1/0 sur les trois passages | 9/1/0 sur les trois passages |
| 5 000 | 10/1/0 sur les trois passages | 10/1/0, 9/1/0, 10/1/0 |
| 10 000 | 9/0/0 sur les trois passages | 9/0/0 sur les trois passages |

Ces compteurs couvrent toute la boucle, y compris recherches, ticks et validations. Ils ne sont ni séparés par phase ni exportés tick par tick. Ils ne donnent pas la durée des pauses. Les allocations sont limitées au thread courant ; le pic de RAM du processus et la mémoire conservée par les index et historiques ne sont pas mesurés.

## 7. Correspondance avec le code et limites

Dans la version sans index, `EngagementSystem.DetectProvinceEngagements()` utilise `_engagements.FirstOrDefault(...)` (vers la ligne 99). Les archives précèdent les engagements actifs dans la liste. Cette partie peut coûter O(P x (H + A)), pour P provinces, H archives et A engagements actifs. Avec 50 provinces et 10 000 archives, environ un demi-million d'engagements sont examinés par passe.

Dans la version indexée, la méthode utilise `_activeProvinceEngagements.TryGetValue()` (vers la ligne 140). Cette recherche ne parcourt plus l'historique. La méthode entière n'est pas O(1), car les divisions sont toujours parcourues et regroupées.

`ActiveEngagements` et `ProcessEngagements()` changent aussi : filtrage de l'historique puis `ToList()` en C1.2c, collection active dédiée puis `ToArray()` en C1.2d. Le bénéfice attendu sur la dépendance à l'historique est cohérent avec les mesures ciblées.

Limites déterminantes :

1. Les 24 ticks d'échauffement ne suffisent pas à produire une période temporelle stable.
2. Cinq recherches supplémentaires précèdent chaque tick et peuvent influencer l'état du runtime sans être incluses dans son chronométrage.
3. La préparation hors mesure dépend de la version et de H : H10000 prend environ 510–565 ms sans index contre 286–323 ms avec index. Elle peut laisser un runtime dans un état différent.
4. Les validations hors chronométrage ont elles-mêmes un coût différent : `ActiveEngagements.Count()` parcourt l'historique sans index, pas avec la collection active dédiée.
5. Trois processus par configuration restent un échantillon limité. Les 216 observations regroupées ne sont pas 216 expériences indépendantes.
6. L'ordre des historiques reste fixe, même si l'ordre des versions est alterné.
7. Aucune bataille active ne se termine pendant la mesure. Renforts, nouvelles batailles, mouvements et rencontres en transit ne sont pas couverts par cette campagne statique.
8. Aucun char et aucun moteur tactique hybride ne sont simulés ici.
9. Les exports n'attestent pas du succès de la suite de tests. Aucun test n'a été relancé lors de l'analyse ni de l'archivage.

## 8. Résultats individuels

Chaque cellule de temps est `moyenne / médiane / p95`, en ms. Les PID identifient les fichiers CSV/JSON dans les sous-dossiers de l'archive.

| Archives | Version | Passage / PID | Recherche / passe | Tick complet |
|---:|---|---|---|---|
| 0 | C1.2c | 1 / 9929 | 0,149 / 0,141 / 0,221 | 7,014 / 6,747 / 12,673 |
| 0 | C1.2c | 2 / 10273 | 0,141 / 0,140 / 0,203 | 6,671 / 5,662 / 11,991 |
| 0 | C1.2c | 3 / 10542 | 0,119 / 0,133 / 0,161 | 6,885 / 4,925 / 11,917 |
| 0 | C1.2d | 1 / 9967 | 0,116 / 0,112 / 0,166 | 6,015 / 5,540 / 15,194 |
| 0 | C1.2d | 2 / 10236 | 0,118 / 0,113 / 0,161 | 6,366 / 5,591 / 13,882 |
| 0 | C1.2d | 3 / 10579 | 0,117 / 0,110 / 0,154 | 6,176 / 5,266 / 14,938 |
| 1 000 | C1.2c | 1 / 10004 | 0,441 / 0,290 / 1,566 | 6,651 / 5,551 / 14,993 |
| 1 000 | C1.2c | 2 / 10348 | 0,415 / 0,291 / 1,530 | 6,359 / 5,474 / 13,538 |
| 1 000 | C1.2c | 3 / 10616 | 0,372 / 0,286 / 1,547 | 7,506 / 5,607 / 17,797 |
| 1 000 | C1.2d | 1 / 10042 | 0,114 / 0,104 / 0,155 | 6,409 / 4,951 / 16,441 |
| 1 000 | C1.2d | 2 / 10310 | 0,095 / 0,083 / 0,174 | 7,955 / 3,098 / 20,810 |
| 1 000 | C1.2d | 3 / 10654 | 0,099 / 0,104 / 0,153 | 7,914 / 3,322 / 17,666 |
| 5 000 | C1.2c | 1 / 10081 | 0,843 / 0,363 / 2,032 | 5,599 / 3,343 / 15,334 |
| 5 000 | C1.2c | 2 / 10424 | 1,341 / 0,350 / 7,580 | 4,683 / 3,179 / 14,618 |
| 5 000 | C1.2c | 3 / 10692 | 0,691 / 0,348 / 5,517 | 4,290 / 3,231 / 15,663 |
| 5 000 | C1.2d | 1 / 10122 | 0,133 / 0,110 / 0,165 | 6,739 / 5,511 / 15,595 |
| 5 000 | C1.2d | 2 / 10386 | 0,133 / 0,113 / 0,167 | 6,095 / 5,339 / 16,999 |
| 5 000 | C1.2d | 3 / 10730 | 0,128 / 0,110 / 0,144 | 7,531 / 5,461 / 12,836 |
| 10 000 | C1.2c | 1 / 10160 | 0,908 / 0,904 / 0,975 | 3,749 / 3,707 / 4,176 |
| 10 000 | C1.2c | 2 / 10503 | 0,869 / 0,863 / 0,959 | 3,849 / 3,793 / 4,577 |
| 10 000 | C1.2c | 3 / 10768 | 0,862 / 0,843 / 0,995 | 3,774 / 3,666 / 4,699 |
| 10 000 | C1.2d | 1 / 10198 | 0,069 / 0,037 / 0,128 | 6,913 / 2,760 / 17,837 |
| 10 000 | C1.2d | 2 / 10465 | 0,078 / 0,066 / 0,126 | 6,025 / 3,016 / 17,233 |
| 10 000 | C1.2d | 3 / 10806 | 0,068 / 0,048 / 0,169 | 7,071 / 2,762 / 17,922 |

## 9. Recommandation de clôture

Critères validés : même outil de mesure, charge historique et active conforme, états militaires agrégés conservés, recherche indexée beaucoup moins sensible au volume d'archives.

Non établis : accélération globale du tick, absence de régression globale dans un protocole stationnaire, succès actuel de la suite de tests.

Recommandation : conserver l'indexation et considérer son objectif algorithmique atteint. Confirmer les tests verts avant clôture formelle. Ne pas annoncer un gain global de simulation à partir de cette campagne.

Le passage à C2 est raisonnable avec une priorité méthodologique : stabiliser l'échauffement et distinguer un benchmark de recherche isolée d'un benchmark de ticks sans appels supplémentaires de diagnostic. Une comparaison courte avec ce protocole permettrait de réexaminer les écarts globaux avant de les qualifier de régression intrinsèque. Ne pas prolonger indéfiniment C1.2d par des optimisations spéculatives des plateaux.

Les fichiers sources cités dans ce rapport se trouvent aux chemins `src/WoF.Benchmarks/HistoryBenchmark.cs`, `src/WoF.Simulation/Military/Combat/EngagementSystem.cs`, `src/WoF.Benchmarks/BenchmarkMilitaryState.cs` dans les snapshots des deux versions. Les résultats originaux et leurs métadonnées font autorité pour les valeurs non arrondies ; le manifeste en inventorie les noms exacts.
